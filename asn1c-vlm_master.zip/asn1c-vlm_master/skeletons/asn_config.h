// An empty stub for an automatically generated file. Don't edit manually!
